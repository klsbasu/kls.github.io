import os

folder_path = "./"

for i in range(71):
    old_name = f"frame_{i:02}_delay-0.03s.gif"
    new_name = f"player_{i:02}.gif"
    
    if os.path.exists(os.path.join(folder_path, old_name)):
        os.rename(os.path.join(folder_path, old_name), os.path.join(folder_path, new_name))
        print(f"Renamed: {old_name} -> {new_name}")
    else:
        print(f"File not found: {old_name}")
