# Spielvorlage

# notwendige Bibliotheken importieren
import pgzrun  
from pgzhelper import *  
import random  
import math  

# Spielfenster definieren
WIDTH = 800  
HEIGHT = 600  
TITLE = "Code-Vorlage"

# background laden
background = Actor("grass")  

# player erstellen
player = Actor("player_images/player_00")  
player.images = [f'player_images/player_{i:02}' for i in range(71)]  # Animation Frames generieren
player.fps = 20  
player.x = 200  
player.y = 200  

# enemy erstellen
enemy = Actor("enemy_images/enemy_00")  
enemy.images = [f'enemy_images/enemy_{i:02}' for i in range(95)]  # Animation Frames generieren
enemy.fps = 20  
enemy.x = 400  
enemy.y = 400  

# apple platzieren
apple = Actor("apple")  
apple.x = random.randint(0, 400)  # zufällige Position setzen  
apple.y = random.randint(0, 500)  

# Punkte und timer initialisieren
score = 0  
timer = 0  

# Listen für game objects erstellen
candies = []  
waterballs = []  
fireballs = []  

# Abklingzeit für waterballs setzen
waterball_holdoff = 0  

# Spiellogik definieren
def update():
    global score  
    global waterball_holdoff  
    global timer  

    # timer aktualisieren
    timer += 1 / 60  

    # player und enemy animieren
    player.animate()  
    enemy.animate()  

    # player bewegen
    if keyboard.a and player.x > 0:  
        player.x -= 5  
    if keyboard.d and player.x < WIDTH:  
        player.x += 5  
    if keyboard.w and player.y > 0:  
        player.y -= 5  
    if keyboard.s and player.y < HEIGHT:  
        player.y += 5  

    # enemy dem player folgen lassen
    if enemy.x < player.x:  
        enemy.x += 0.5  
    if enemy.x > player.x:  
        enemy.x -= 0.5  
    if enemy.y < player.y:  
        enemy.y += 0.5  
    if enemy.y > player.y:  
        enemy.y -= 0.5  

    # player-apple-Kollision prüfen
    if apple.colliderect(player):  
        score += 1  
        print("Apfel gegessen!")  
        apple.x = random.randint(0, 400)  
        apple.y = random.randint(0, 400)  

    # player-enemy-Kollision prüfen
    if enemy.colliderect(player):  
        score = 0  
        print("Spieler verletzt! Spiel vorbei!")  
        player.x = random.randint(0, 400)  
        player.y = random.randint(0, 400)  

    # candies zufällig erscheinen lassen
    if len(candies) < 3 and random.randint(0, 50) == 0:  
        candy = Actor("candy")  
        candy.x = random.randint(0, WIDTH)  
        candy.y = random.randint(0, HEIGHT)  
        candies.append(candy)  

    # candies einsammeln
    for candy in candies[:]:  
        if candy.colliderect(player):  
            score += 5  
            candies.remove(candy)  
            print("Bonbon gesammelt!")  

    # waterball abschießen
    if keyboard.f and waterball_holdoff == 0:  
        waterball = Actor("waterball")  
        waterball.x = player.x + 20  
        waterball.y = player.y  

        # Geschwindigkeit berechnen
        dx = enemy.x - waterball.x  
        dy = enemy.y - waterball.y  
        distance = (dx**2 + dy**2) ** 0.5  
        waterball.vx = (dx / distance) * 10  
        waterball.vy = (dy / distance) * 10  

        waterballs.append(waterball)  
        waterball_holdoff = 20  

    # Abklingzeit reduzieren
    if waterball_holdoff > 0:  
        waterball_holdoff -= 1  

    # waterballs bewegen
    for waterball in waterballs:  
        waterball.x += waterball.vx  
        waterball.y += waterball.vy  

    # waterballs außerhalb des Spielfensters entfernen
    for waterball in waterballs[:]:  
        if waterball.x < 0 or waterball.x > WIDTH or waterball.y < 0 or waterball.y > HEIGHT:  
            waterballs.remove(waterball)  

    # prüfen, ob enemy von waterball getroffen wird
    for waterball in waterballs:  
        if waterball.colliderect(enemy):  
            print("Feind verletzt!")  
            enemy.x = random.randint(0, 400)  
            enemy.y = random.randint(0, 400)  

    # fireballs zufällig erzeugen
    if random.randint(0, 1000) > 990:  
        fireball = Actor("fireball")  
        fireball.x = enemy.x  
        fireball.y = enemy.y  
        fireball.angle = random.randint(0, 359)  
        fireballs.append(fireball)  

    # fireballs bewegen und außerhalb des Spielfensters entfernen
    for fireball in fireballs[:]:  
        fireball.move_forward(5)  
        if fireball.x < 0 or fireball.x > WIDTH or fireball.y < 0 or fireball.y > HEIGHT:  
            fireballs.remove(fireball)  

    # prüfen, ob player von fireball getroffen wird
    for fireball in fireballs:  
        if fireball.colliderect(player):  
            print("Spieler verletzt!")  
            player.x = random.randint(0, 400)  
            player.y = random.randint(0, 400)  

# Zeichenfunktion definieren
def draw():  
    screen.clear()  
    background.draw()  
    player.draw()  
    enemy.draw()  
    apple.draw()  

    for candy in candies:  
        candy.draw()  

    for waterball in waterballs:  
        waterball.draw()  

    for fireball in fireballs:  
        fireball.draw()  

    # score und timer anzeigen
    screen.draw.text('Punkte: ' + str(score), (15, 10), color=(255, 255, 255), fontsize=30)  
    screen.draw.text('Zeit: ' + str(round(timer)), (130, 10), color=(255, 255, 255), fontsize=30)  

# Spiel starten
pgzrun.go()
